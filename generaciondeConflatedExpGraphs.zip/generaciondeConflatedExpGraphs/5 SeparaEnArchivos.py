#Lista5 a semiLista x
#separa las lineas en archivos distintos segun prefijos
#atencion al range 11, pues los prefijos llegan hasta 10
suma=0

for i in range(11):

    x=str(i)
    g = open('SemiLista'+x+'.txt', 'w')
    f = open('Lista5.txt', 'r')
    for linea in f:

        suma = int(linea[0:2])
        if suma == i:
            g.write(linea[:-1]+'\n')
    g.closed    
    f.closed    
