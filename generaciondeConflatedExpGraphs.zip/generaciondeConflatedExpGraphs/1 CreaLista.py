#Lista a Lista2
#borra espacios

f = open('Lista.txt', 'r')
g = open('Lista2.txt','w')
for line in f:
    linea = str(line).replace(' ', '')
    g.write(linea)

f.closed
g.closed






