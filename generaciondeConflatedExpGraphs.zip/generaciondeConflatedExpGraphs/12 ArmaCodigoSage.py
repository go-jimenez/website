#genera el archivo con el codigo listo para sage
g=open('AAAAAAFinal.txt','w')
for r in range(11):
    x=str(r)
    f = open('RelatedA'+x+'ConjuntosSimp2.txt','r')
    for line in f:
        #if line != '':
        #    g.write('H.merge_vertices('+str(line)+');')
        g.write('H.merge_vertices('+str(line[:len(line)-1])+');'+'\n')
    f.closed
g.closed