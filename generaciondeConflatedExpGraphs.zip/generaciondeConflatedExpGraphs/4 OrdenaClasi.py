#Lista4 a Lista5
#reordena las lineas segun el prefijo agregado de forma creciente
g = open('Lista5.txt','w')

i=0
while i< 10:

    f = open('Lista4.txt', 'r')
    for line in f:

        if int(line[0])==0 and int(line[1])==i:
            g.write(str(line[:len(line)-1]+'\n'))
    f.closed
    i= i+1

f = open('Lista4.txt', 'r')
for line in f:

    if int(line[0])==1:
        g.write(str(line[:len(line)-1]+'\n')) 
    
f.closed
g.closed






