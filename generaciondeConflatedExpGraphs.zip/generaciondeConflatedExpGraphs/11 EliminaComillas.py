#RelatedAXConjuntosSimp a RelatedAXConjuntosSimp2

for r in range(11):

    x=str(r)
    f = open('RelatedA'+x+'ConjuntosSimp.txt', 'r')
    g = open('RelatedA'+x+'ConjuntosSimp2.txt','w')
    for line in f:
        linea = str(line).replace("'", "")
        g.write(linea)

    f.closed
    g.closed