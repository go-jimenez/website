#SemiLista y SemiListaXRelated a SemiListaXRelatedA
j=0
k=0
for i in range(5):

    x=str(i)
    e = open('SemiLista'+x+'RelatedA.txt', 'w')
    f = open('SemiLista'+x+'.txt','r')
    for linea in f:
        j=int(linea[16:-1])
        if j<10:
            e.write('00'+str(j))
        elif 9<j<100:
            e.write('0'+str(j))
        else:
            e.write(str(j))

        g = open('SemiLista'+x+'Related.txt', 'r')
        for lin in g:

            p=lin.find('-')
            t=int(lin[:p])
            if j==t:
                e.write(lin[p:-1])   
        g.closed
        e.write('\n')     
    e.closed  
    f.closed  