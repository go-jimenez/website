#Lista5 a semiLista x
#separa las lineas en archivos distintos segun prefijos
#atencion al range 5, pues los prefijos llegan hasta 4
suma=0

for i in range(5):

    x=str(i)
    g = open('SemiLista'+x+'.txt', 'w')
    f = open('Lista5.txt', 'r')
    for linea in f:

        suma = int(linea[0:2])
        if suma == i:
            g.write(linea[:-1]+'\n')
    g.closed    
    f.closed    
