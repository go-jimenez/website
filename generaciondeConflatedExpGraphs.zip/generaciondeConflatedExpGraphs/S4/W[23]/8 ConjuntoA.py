#SemilistaXRelatedA a RelatedAXConjuntos 
#rango 11 por numero de archivos
for r in range(5):
    x=str(r)
    f = open('SemiLista'+x+'RelatedA.txt','r')

    j=0
    B=[]
    for line in f:
        A=line.split('-')
        n=int(A[len(A)-1])
        A.remove(A[len(A)-1])
        for i in range(len(A)):
            A[i]=int(A[i])
        A.append(n)
        B.append(set(A))
        j=j+1
    J=j
    g = open('RelatedA'+x+'Conjuntos.txt','w')

    D=[]

    for i in range(j):
        F=set(B[i])
        #print(i)
        for l in range(J):
            if B[i].isdisjoint(B[l])==False:
                F=F.union(B[l])
        #print(F)
        g.write(str(F)+'\n')
        D.append(F)
    
    g.closed 

    f.closed