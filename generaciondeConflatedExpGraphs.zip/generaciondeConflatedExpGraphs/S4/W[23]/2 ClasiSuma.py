#Lista2 a Lista3
#escribe la suma de las coordenadas en cada linea y lo pone delante

f = open('Lista2.txt', 'r')
g = open('Lista3.txt','w')
contLinea=0
sumaMinima=0
countComas=0
for line in f:
    if contLinea==0:
        countComas=line.count(",")
    suma=0
    l=0
    for j in range(countComas):
        l=2*j+1
        suma = int(line[l])+suma
    if contLinea==0:
        sumaMinima=suma
    k = suma-sumaMinima 
    K=str(k)
    if k<10:
        g.write('0'+K + str(line[:-1])+'\n')
    else:
        g.write(K + str(line[:-1])+'\n')
    contLinea+=1
    
f.closed
g.closed






