#SemiListaX a SemiListaXRelated
#i en rango 5 por ser el numero de archivos
#j en rango 6 por cantidad de entradas en la linea
for i in range(5):

    x=str(i)
    g = open('SemiLista'+x+'.txt', 'r')
    #h = open('SemiLista'+x+'.txt', 'r')
    f = open('SemiLista'+x+'Related.txt', 'w')

    aux=0
    index=0
    for linea in g:

        h = open('SemiLista'+x+'.txt', 'r')

        for line in h:
        
            for j in range(6):
                l=2*j+3
                if linea[l]!=line[l]:
                    #cuenta cuantas veces son distintos los pares de lineas
                    aux=aux+1
                    index=l
                    #guarda el ultimo lugar distinto
            if aux == 2:
                #cuando son distintas las lineas en solo 2 lugares
                if linea[index-2]==line[index] and line[index-2]==linea[index]:
                    f.write(linea[linea.find(')')+2:-1]+'-'+line[line.find(')')+2:])
            else:
                f.write(linea[linea.find(')')+2:-1]+'-'+linea[linea.find(')')+2:])

            aux=0    
        index=0
        h.closed    
    g.closed
    f.closed    
    
