#RelatedAXConjuntosIter1 a RelatedAXConjuntosSimp

for r in range(11):
    x=str(r)
    f = open('RelatedA'+x+'ConjuntosIter1.txt','r')
    j=0
    B=[]
    #C=[]
    for line in f:
        A=line[1:len(line)-2].split(', ')
        B.append(A)
        #C.append(A)
        #hasta aca he definido B como arreglo de conjuntos de numeros 
        #(cada entrada del arreglo es un conjunto de numeros correspondiente a una linea de f)
        j=j+1
    J=j
    f.closed
    #print(B)
    D=[]
    D.append(B[0])

    for i in range(len(B)):
        k=0
        for l in range(len(D)):
            if set(B[i]).isdisjoint(set(D[l]))==False:
                k=k+1
        if k==0:
            D.append(B[i])
    print(D)

    g = open('RelatedA'+x+'ConjuntosSimp.txt','w')

    for p in range(len(D)):
        g.write(str(D[p])+'\n')
    g.closed
    
    