#Lista3 a Lista4
#Escribe el numero de linea al final
f = open('Lista3.txt', 'r')
g = open('Lista4.txt', 'w')
i=1
#for linea in f:
#    x=str(i)
#    g.write(linea[:-1]+x+'\n')
#    i=int(x)
#    i=i+1
#    
#f.closed
#g.closed

######
for linea in f:

    if i<10:
        x=str(i)
        g.write(linea[:-1]+'00'+x+'\n')
        i=int(x)
        i=i+1
    elif 9<i<100:
        x=str(i)
        g.write(linea[:-1]+'0'+x+'\n')
        i=int(x)
        i=i+1
    else:
        x=str(i)
        g.write(linea[:-1]+x+'\n')
        i=int(x)
        i=i+1

f.closed
g.closed