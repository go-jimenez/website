#Lista2 a Lista3
#escribe la suma de las coordenadas en cada linea y lo pone delante

f = open('Lista2.txt', 'r')
g = open('Lista3.txt','w')

for line in f:
    suma=0
    l=0
    for j in range(10):
        l=2*j+1
        suma = int(line[l])+suma
    k = suma-20 
    K=str(k)
    if k<10:
        g.write('0'+K + str(line[:-1])+'\n')
    else:
        g.write(K + str(line[:-1])+'\n')
    
f.closed
g.closed






