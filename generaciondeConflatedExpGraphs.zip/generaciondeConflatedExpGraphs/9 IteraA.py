
for r in range(11):

    x=str(r)
    f = open('RelatedA'+x+'Conjuntos.txt','r')

    j=0
    B=[]
    for line in f:
        A=line[1:len(line)-2].split(', ')
        
        for i in range(len(A)):
            A[i]=int(A[i])
        B.append(set(A))
        j=j+1
    print(str(j))
    J=j
    g = open('RelatedA'+x+'ConjuntosIter1.txt','w')
    #D=[]

    for i in range(j):
        F=set(B[i])
        for l in range(J):
            if B[i].isdisjoint(B[l])==False:
                F=F.union(B[l])
        g.write(str(F)+'\n')
        #D.append(F)
    g.closed 

    f.closed